# qt_imports.py
from PySide6.QtWidgets import (
    QApplication, QWidget, QMainWindow, QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QFormLayout, QStackedWidget, QListWidget, QListWidgetItem, QPushButton, QLabel,
    QLineEdit, QTextEdit, QComboBox, QCheckBox, QRadioButton, QTabWidget, QTableWidget, 
    QTableWidgetItem, QMessageBox, QFileDialog, QProgressBar, QSlider, QScrollArea, 
    QGridLayout, QHBoxLayout, QLabel, QMainWindow, QPushButton, QSizePolicy,QSpacerItem,
    QStackedWidget, QVBoxLayout, QWidget, QFrame, QDialogButtonBox, QSpinBox, QTabWidget,
    QToolTip, QListView, QGraphicsDropShadowEffect, QStyle, QLayout, QFileDialog, QGraphicsView,
    QMenu, QInputDialog, QGraphicsOpacityEffect, QToolButton, QToolBar, QStatusBar, QAbstractButton, 
    QTabBar, QTextBrowser
    
    
)

from PySide6.QtCore import (
    QCoreApplication, QDate, QDateTime, QLocale, QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt, QFile, QTextStream, QByteArray, QSize, Qt, QRectF, Signal, Slot,
    QEvent, QRegularExpression, QSettings, QTimer, QPropertyAnimation, QEasingCurve, Property, 
    QParallelAnimationGroup, QSequentialAnimationGroup, QAbstractAnimation, 
    
)

from PySide6.QtGui import (
    QBrush, QColor, QConicalGradient, QCursor, QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter, QPalette, QPixmap, QRadialGradient, 
    QTransform, QIcon, QPixmap, QPainter, QDoubleValidator, QRegularExpressionValidator, 
    QShortcut, QIntValidator, QPen, QPainterPath, QKeyEvent, QTextDocument, QAction, QRegion, 
    QFontMetrics, 
    
)

from PySide6.QtSvg import (
    QSvgRenderer, 
)

from PySide6.QtPrintSupport import (
    QPrintDialog, QPrinter, QPrintPreviewDialog, 
)


