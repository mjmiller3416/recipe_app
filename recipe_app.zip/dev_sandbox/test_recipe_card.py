test_window = None  # 👈 Define globally

def run_test(app):
    global test_window  # 👈 Make sure this stays alive!

    from core.modules.recipe_module import Recipe
    from dev_sandbox.recipe_card import RecipeCard
    from PySide6.QtWidgets import QWidget, QHBoxLayout

    MOCK_RECIPE = {
        "id": 101,
        "recipe_name": "Lentil Soup",
        "recipe_category": "Soup",
        "total_time": 45,
        "servings": 4,
        "image_path": "recipe_images/lentil_soup.jpg"
    }

    recipe = Recipe(MOCK_RECIPE)

    test_window = QWidget()  # 👈 Store globally so it's not garbage collected
    test_window.setWindowTitle("RecipeCard Sandbox")

    layout = QHBoxLayout(test_window)
    layout.addWidget(RecipeCard(recipe, layout_mode="full"))
    layout.addWidget(RecipeCard(recipe, layout_mode="mini"))

    test_window.resize(1000, 400)
    test_window.show()
