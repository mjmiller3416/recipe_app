"""
Initialization file for the app.ingredients package.

Contains the Meal Planner class and its associated UI components.
"""

from .meal_planner import MealPlanner