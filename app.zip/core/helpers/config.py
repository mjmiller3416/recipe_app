# Package: app/config.py

# Description: This file contains configuration constants and validation rules for the application.
# It includes measurement units, ingredient categories, recipe categories, and validation rules for user input.

#🔸System Imports
from pathlib import Path

#🔸Local Imports
from core.helpers.qt_imports import (
    QDoubleValidator, QRegularExpressionValidator, QRegularExpression, QIntValidator, QSize
    )

#🔹DIRECTORY PATHS
BASE_DIR = Path(__file__).resolve().parents[2]
ASSETS_DIR = BASE_DIR / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
IMAGES_DIR = ASSETS_DIR / "images"
RECIPE_IMAGES_DIR = ASSETS_DIR / "recipe_images"

#🔹ICON DEFAULTS
ICON_SIZE = QSize(20, 20) 
ICON_COLOR = "#949aa7" 
ICON_COLOR_HOVER = "#03B79E"
ICON_COLOR_CHECKED = "#03B79E"

# 🔹 DIALOG COLORS
SUCCESS_COLOR = "#5cde42"
ERROR_COLOR = "#ff4d4d"
WARNING_COLOR = "#ffcc00"
INFO_COLOR = "#03B79E"

# 🔹 LOGO COLOR
LOGO_COLOR = "#949aa7"

#🔹COMBOBOX VALUES
MEASUREMENT_UNITS = [
    "bag", "box", "can", "cap-full", "cup", "gallon", "half", "jar",
    "oz.", "pack", "pinch", "pint", "lb.", "quarter", "slice",
    "square", "strip", "Tbs", "tsp", "whole"
]

INGREDIENT_CATEGORIES = [
    "bakery", "baking", "dairy", "deli", "oils", "frozen",
    "meat", "pantry", "produce", "seafood", "spices", "other"
]

RECIPE_CATEGORIES = [
    "Breakfast", "Lunch", "Dinner", "Snack", "Dessert"
]

#🔹VALIDATION RULES
NAME = lambda parent: QRegularExpressionValidator(QRegularExpression(r"^[a-zA-Z0-9\s\-]+$"), parent)
FLOAT = lambda parent: QRegularExpressionValidator(QRegularExpression(r"^\d{1,2}(\.\d{0,2})?$"), parent)
INT = lambda parent: QRegularExpressionValidator(QRegularExpression(r"^\d{1,3}$"), parent)
NON_EMPTY = lambda parent: QRegularExpressionValidator(QRegularExpression(r"^(?!\s*$).+"), parent)

def icon_path(name: str) -> str:
    return str(ICONS_DIR / f"{name}.svg") # All icons must be SVG

def image_path(name: str) -> str:
    return str(IMAGES_DIR / f"{name}.svg")  # All images must be PNG

def recipe_image_path(name: str) -> str:
    return str(IMAGES_DIR / f"{name}.png")  # All recipe images must be PNG
 
