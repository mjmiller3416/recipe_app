"""database/db_reset.py

Handles database reset operations for MealGenie.
"""

import os
import sys
from database.app_database import ApplicationDatabase
from core.helpers import DebugLogger


def reset_database():
    """Reset the application database using the new structure."""
    DebugLogger().log("Resetting database...", "warning")

    db = ApplicationDatabase()
    db_path = db.db_path

    # 1. Delete old DB
    if os.path.exists(db_path):
        os.remove(db_path)
        DebugLogger().log(f"Deleted existing database at {db_path}", "info")
    else:
        DebugLogger().log("No existing database to delete.", "info")

    # 2. Recreate schema
    db.create_schema()

    # 3. Optional: Seed data (disabled by default)
    # db.insert_seed_data()

    DebugLogger().log("Database reset complete.\n", "success")
    sys.exit(0)
